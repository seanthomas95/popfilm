import React from 'react';



class About extends React.Component {
  constructor() {
    super();

  }

  render(){
    return (
      <h1>BIG H1 </h1>
    );



  }

}





export default About;